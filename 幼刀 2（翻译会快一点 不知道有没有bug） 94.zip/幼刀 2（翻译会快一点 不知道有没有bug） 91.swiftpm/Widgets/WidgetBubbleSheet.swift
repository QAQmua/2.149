// 📄 完整替换文件：Widgets/WidgetBubbleSheet.swift
import SwiftUI
import PhotosUI

// MARK: - 对话框小组件专属编辑面板（多米诺逐行级联全量覆盖 · 26pt 饱满同心 · 全功能版）
@MainActor
struct EditBubbleWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var chatBubbleManager = ChatBubbleWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    // 是否吸顶置顶预览
    @AppStorage("W_BB_PinPreview") private var isPreviewPinned: Bool = true
    
    // 两大顶级分类：0: 样式 (外观、形态与调色), 1: 内容 (文本与配图)
    @State private var selectedCategoryTab: Int = 0
    @State private var selectedBubblePhotoItem: PhotosPickerItem? = nil
    
    // 🌟 多米诺视口感知联合触发键
    private var triggerKey: String { "\(selectedCategoryTab)" }
    
    // HSB 调色面板状态绑定
    @State private var colorPickerTitle: String = ""
    @State private var colorStorageKey: String = ""
    @State private var activeHexBinding: Binding<String>? = nil
    @State private var activePresetColors: [String] = []
    @State private var showHSBSheet: Bool = false
    
    // 预设色盘
    private var morandiPresets: [String] { SystemAppearance.morandiPresets }
    private let widgetBgPresets = ["#F2F2F7", "#FFFFFF", "#EDEDF2", "#1C1C1E", "#EAF0F8", "#FCE7EC", "#E8F5E9", "#F2EBE5"]
    private let bubbleColorPresets = ["#E5E5EA", "#FFFFFF", "#1C1C1E", "#D0E1FD", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#E8DFF5"]
    private let borderPresets = ["#D1D1D6", "#E5E5EA", "#000000", "#FFFFFF", "#8E8E93", "#007AFF", "#FF2D55", "#FF9500"]
    private let textColorPresets = ["#000000", "#FFFFFF", "#3C3C43", "#007AFF", "#FF2D55", "#5856D6"]
    private let dateColorPresets = ["#8E8E93", "#000000", "#FFFFFF", "#007AFF", "#FF9500"]
    private let shareBgPresets = ["#8E8E93", "#000000", "#FFFFFF", "#007AFF", "#FF2D55", "#5856D6", "#E5E5EA"]
    private let shareIconPresets = ["#FFFFFF", "#000000", "#E5E5EA", "#007AFF", "#FF2D55"]
    
    private let fontWeights: [(key: String, title: String)] = [
        ("light", "细体"),
        ("regular", "常规"),
        ("medium", "中等"),
        ("semibold", "半粗"),
        ("bold", "粗体")
    ]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                // 1. 【置顶预览区：通体同色系统底板】
                if isPreviewPinned {
                    pinnedHeaderView(s: s)
                        .zIndex(10)
                }
                
                // 2. 【滚动内容区：细颗粒度多米诺逐行级联卡片流】
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !isPreviewPinned {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        if selectedCategoryTab == 0 {
                            styleCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 4)
                        } else {
                            contentCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 4)
                        }
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("对话框".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            isPreviewPinned.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isPreviewPinned ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(isPreviewPinned ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(isPreviewPinned ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            // 🌟 专业 HSB 调色大弹窗
            .sheet(isPresented: $showHSBSheet) {
                if let hexBinding = activeHexBinding {
                    ProfessionalHSBSheet(
                        title: colorPickerTitle,
                        storageKey: colorStorageKey,
                        hexBinding: hexBinding,
                        presets: activePresetColors
                    )
                    .presentationDetents([.height(400)])
                }
            }
            .task(id: selectedBubblePhotoItem) {
                if let data = try? await selectedBubblePhotoItem?.loadTransferable(type: Data.self) {
                    await MainActor.run {
                        withAnimation(.easeInOut(duration: 0.28)) {
                            chatBubbleManager.widgetImageData = data
                        }
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                        selectedBubblePhotoItem = nil
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    // MARK: - 🏆 顶部吸顶区域
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            ChatBubbleWidget2x2View(
                imageData: chatBubbleManager.widgetImageData,
                firstBubbleText: chatBubbleManager.firstBubbleText,
                secondBubbleText: chatBubbleManager.secondBubbleText,
                isTransparent: chatBubbleManager.isTransparentBackground,
                widgetBgColor: chatBubbleManager.widgetBgColor,
                bubbleColor: chatBubbleManager.bubbleColor,
                bubbleTextColor: chatBubbleManager.bubbleTextColor,
                dateTextColor: chatBubbleManager.dateTextColor,
                bubbleTextWeight: chatBubbleManager.bubbleTextWeight,
                showDashedBorder: true
            )
            .frame(width: 155 * s, height: 155 * s)
            .shadow(color: Color.black.opacity(0.06), radius: 8, y: 3)
            .contentShape(Rectangle())
            
            Picker("", selection: $selectedCategoryTab.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                Text("样式".tr).tag(0)
                Text("内容".tr).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 24)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    // MARK: - 📁 分类 1：【样式】（每一行均接入独立递增的 Domino 多米诺骨牌）
    private func styleCategorySection() -> some View {
        VStack(spacing: 16) {
            // 1. 底板背景卡片
            VStack(spacing: 16) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Picker("", selection: $chatBubbleManager.bgColorMode.animation(.easeInOut(duration: 0.2))) {
                        Text("自选底色".tr).tag("color")
                        Text("完全透明".tr).tag("transparent")
                    }
                    .pickerStyle(.segmented)
                }
                
                if chatBubbleManager.bgColorMode == "color" {
                    DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                        sleekColorRow(
                            title: "底板背景颜色".tr,
                            storageKey: "bb_widget_bg",
                            hexBinding: $chatBubbleManager.widgetBgColorHex,
                            presets: widgetBgPresets
                        )
                    }
                }
            }
            .modifier(IOSNativeGroupedCard())
            
            // 2. 配图专属卡片
            VStack(spacing: 18) {
                // 配图圆角
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("配图圆角".tr)
                                .font(.system(size: 15, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary)
                            Spacer()
                            Text(String(format: "%.0f pt", chatBubbleManager.imageCornerRadius))
                                .font(.system(size: 13, weight: .medium, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                        Slider(value: $chatBubbleManager.imageCornerRadius, in: 0.0...24.0, step: 1.0)
                            .tint(appearance.sliderTrackColor)
                    }
                }
                
                // 配图外描边开关
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    Toggle(isOn: $chatBubbleManager.hasImageBorder.animation(.spring(response: 0.35, dampingFraction: 0.8))) {
                        Label("配图外描边".tr, systemImage: "square.dashed")
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                    }
                    .tint(appearance.toggleTintColor)
                }
                
                // 🌟 描边从属灰色盒子内部：逐行级联多米诺
                if chatBubbleManager.hasImageBorder {
                    VStack(spacing: 14) {
                        DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("描边粗细".tr)
                                        .font(.system(size: 14, weight: appearance.systemFontWeight))
                                        .foregroundColor(.secondary)
                                    Spacer()
                                    Text(String(format: "%.1f pt", chatBubbleManager.imageBorderWidth))
                                        .font(.system(size: 12, weight: .medium, design: .monospaced))
                                        .foregroundColor(.secondary)
                                }
                                Slider(value: $chatBubbleManager.imageBorderWidth, in: 0.4...3.0, step: 0.1)
                                    .tint(appearance.sliderTrackColor)
                            }
                        }
                        
                        DominoScrollRevealWrapper(step: 4, triggerKey: triggerKey) {
                            sleekColorRow(
                                title: "描边颜色".tr,
                                storageKey: "bb_img_border",
                                hexBinding: $chatBubbleManager.imageBorderColorHex,
                                presets: borderPresets
                            )
                        }
                    }
                    .modifier(IOSNativeSubBox())
                }
            }
            .modifier(IOSNativeGroupedCard())
            
            // 3. 分享小图标专属卡片
            VStack(spacing: 16) {
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    Toggle(isOn: $chatBubbleManager.showShareIcon.animation(.spring(response: 0.35, dampingFraction: 0.8))) {
                        Label("右侧分享图标".tr, systemImage: "arrowshape.turn.up.right.circle.fill")
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                    }
                    .tint(appearance.toggleTintColor)
                }
                
                // 🌟 分享图标灰色盒子内部：逐行级联多米诺
                if chatBubbleManager.showShareIcon {
                    VStack(spacing: 14) {
                        DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                            sleekColorRow(
                                title: "圆钮底色".tr,
                                storageKey: "bb_share_bg",
                                hexBinding: $chatBubbleManager.shareIconBgHex,
                                presets: shareBgPresets
                            )
                        }
                        
                        DominoScrollRevealWrapper(step: 4, triggerKey: triggerKey) {
                            sleekColorRow(
                                title: "箭头图标颜色".tr,
                                storageKey: "bb_share_ico",
                                hexBinding: $chatBubbleManager.shareIconColorHex,
                                presets: shareIconPresets
                            )
                        }
                    }
                    .modifier(IOSNativeSubBox())
                }
            }
            .modifier(IOSNativeGroupedCard())
            
            // 4. 气泡与字体卡片（全统一单行韵律，逐行级联多米诺）
            VStack(spacing: 16) {
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    HStack {
                        Text("气泡字体粗细".tr)
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                        Spacer()
                        
                        Menu {
                            ForEach(fontWeights, id: \.key) { fw in
                                Button {
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    chatBubbleManager.bubbleTextWeightName = fw.key
                                } label: {
                                    HStack {
                                        Text(fw.title.tr)
                                        if chatBubbleManager.bubbleTextWeightName == fw.key {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                            }
                        } label: {
                            HStack(spacing: 4) {
                                Text(fontWeights.first(where: { $0.key == chatBubbleManager.bubbleTextWeightName })?.title.tr ?? "常规".tr)
                                    .font(.system(size: 15))
                                    .foregroundColor(.secondary)
                                Image(systemName: "chevron.up.chevron.down")
                                    .font(.system(size: 12))
                                    .foregroundColor(.secondary.opacity(0.6))
                            }
                        }
                    }
                }
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    sleekColorRow(
                        title: "气泡底色".tr,
                        storageKey: "bb_bubble_bg",
                        hexBinding: $chatBubbleManager.bubbleColorHex,
                        presets: bubbleColorPresets
                    )
                }
                
                DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                    sleekColorRow(
                        title: "气泡文字颜色".tr,
                        storageKey: "bb_bubble_text",
                        hexBinding: $chatBubbleManager.textColorHex,
                        presets: textColorPresets
                    )
                }
                
                DominoScrollRevealWrapper(step: 4, triggerKey: triggerKey) {
                    sleekColorRow(
                        title: "顶部日期颜色".tr,
                        storageKey: "bb_date_text",
                        hexBinding: $chatBubbleManager.dateColorHex,
                        presets: dateColorPresets
                    )
                }
            }
            .modifier(IOSNativeGroupedCard())
        }
    }
    
    // MARK: - 📝 分类 2：【内容】（逐行逐项级联多米诺）
    private func contentCategorySection() -> some View {
        VStack(spacing: 16) {
            // 对话文案输入卡片
            VStack(spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            TextField("输入第一条气泡文案...".tr, text: $chatBubbleManager.firstBubbleText)
                                .font(.system(size: 15))
                                .onChange(of: chatBubbleManager.firstBubbleText) { _, newText in
                                    translator.prewarm(text: newText)
                                }
                            
                            if !chatBubbleManager.firstBubbleText.isEmpty {
                                Button(action: {
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    chatBubbleManager.firstBubbleText = ""
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .font(.system(size: 16))
                                        .foregroundColor(Color(UIColor.tertiaryLabel))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 12)
                        .background(Color(UIColor.tertiarySystemFill))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                }
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            TextField("输入第二条气泡文案...".tr, text: $chatBubbleManager.secondBubbleText)
                                .font(.system(size: 15))
                                .onChange(of: chatBubbleManager.secondBubbleText) { _, newText in
                                    translator.prewarm(text: newText)
                                }
                            
                            if !chatBubbleManager.secondBubbleText.isEmpty {
                                Button(action: {
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    chatBubbleManager.secondBubbleText = ""
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .font(.system(size: 16))
                                        .foregroundColor(Color(UIColor.tertiaryLabel))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 12)
                        .background(Color(UIColor.tertiarySystemFill))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                }
            }
            .modifier(IOSNativeGroupedCard())
            
            // 气泡展示照片选图卡片
            DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                HStack(spacing: 14) {
                    ZStack {
                        if let data = chatBubbleManager.widgetImageData, let uiImg = UIImage(data: data) {
                            Image(uiImage: uiImg)
                                .resizable()
                                .scaledToFill()
                                .transition(.blurFade)
                        } else {
                            Color(UIColor.tertiarySystemFill)
                            Image(systemName: "photo.badge.plus")
                                .font(.system(size: 20))
                                .foregroundColor(.secondary)
                                .transition(.opacity)
                        }
                    }
                    .frame(width: 52, height: 52)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    
                    PhotosPicker(selection: $selectedBubblePhotoItem, matching: .images, photoLibrary: .shared()) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(chatBubbleManager.widgetImageData == nil ? "选取气泡照片".tr : "更换气泡照片".tr)
                                .font(.system(size: 15, weight: .medium))
                                .foregroundColor(.primary)
                            Text(chatBubbleManager.widgetImageData == nil ? "点击从相册挑选气泡配图".tr : "点击重新选择替换配图".tr)
                                .font(.system(size: 12))
                                .foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    
                    ZStack {
                        if chatBubbleManager.widgetImageData != nil {
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(.easeInOut(duration: 0.28)) {
                                    chatBubbleManager.widgetImageData = nil
                                }
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 20))
                                    .foregroundColor(Color(UIColor.tertiaryLabel))
                                    .frame(width: 32, height: 32)
                                    .contentShape(Circle())
                            }
                            .buttonStyle(.plain)
                        } else {
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(Color(UIColor.tertiaryLabel))
                        }
                    }
                }
                .modifier(IOSNativeGroupedCard())
            }
        }
    }
    
    // MARK: - 🎨 调色整行入口
    private func sleekColorRow(title: String, storageKey: String, hexBinding: Binding<String>, presets: [String]) -> some View {
        Button(action: {
            colorPickerTitle = title
            colorStorageKey = storageKey
            activeHexBinding = hexBinding
            activePresetColors = presets
            showHSBSheet = true
        }) {
            HStack {
                Text(title)
                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                    .foregroundColor(.primary)
                Spacer()
                
                HStack(spacing: 8) {
                    Circle()
                        .fill(hexBinding.wrappedValue.isEmpty ? Color.clear : Color(hex: hexBinding.wrappedValue))
                        .frame(width: 25, height: 25)
                        .overlay(Circle().stroke(Color.primary.opacity(0.12), lineWidth: 1.0))
                    
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Color(UIColor.tertiaryLabel))
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - 🌟 26pt 饱满同心超椭圆大圆角主卡片（接入系统 glassEffect 接口）
private struct IOSNativeGroupedCard: ViewModifier {
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 26, style: .continuous)
        content
            .padding(16)
            .background {
                if #available(iOS 26.0, *) {
                    Color.clear
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .glassEffect(.regular.interactive(), in: shape)
                } else {
                    Color(UIColor.secondarySystemGroupedBackground)
                }
            }
            .clipShape(shape)
            .padding(.horizontal, 16)
    }
}

// MARK: - 🌟 16pt 黄金同心圆角子容器（灰色从属盒子）
private struct IOSNativeSubBox: ViewModifier {
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 16, style: .continuous)
        content
            .padding(14)
            .background {
                if #available(iOS 26.0, *) {
                    Color(UIColor.tertiarySystemFill).opacity(0.55)
                        .glassEffect(.clear, in: shape)
                } else {
                    Color(UIColor.tertiarySystemFill).opacity(0.45)
                }
            }
            .clipShape(shape)
    }
}
