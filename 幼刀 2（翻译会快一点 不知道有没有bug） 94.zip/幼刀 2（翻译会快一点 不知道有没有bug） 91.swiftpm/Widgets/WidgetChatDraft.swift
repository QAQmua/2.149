import SwiftUI
import PhotosUI

// MARK: - 1. 自动装配插座
final class ChatDraftWidgetPlugin: BaseWidgetPlugin {
    @MainActor override class func register() {
        WidgetRegistry.shared.registerChatDraftWidget()
    }
}

// MARK: - 2. 状态管理器 (2×2 规范)
@MainActor
final class ChatDraftWidgetManager: ObservableObject {
    static let shared = ChatDraftWidgetManager()
    
    nonisolated var sizeRows: Int { 2 }
    nonisolated var sizeCols: Int { 2 }
    
    // 桌面定位
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: "W_CD_Added") } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: "W_CD_Page") } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: "W_CD_Row") } }
    @Published var widgetCol: Int { didSet { UserDefaults.standard.set(widgetCol, forKey: "W_CD_Col") } }
    
    // 背景样式与透明度
    @Published var bgColorMode: String { didSet { UserDefaults.standard.set(bgColorMode, forKey: "W_CD_BgMode") } }
    @Published var bgColorHex: String { didSet { UserDefaults.standard.set(bgColorHex, forKey: "W_CD_BgColor") } }
    @Published var bgOpacity: Double { didSet { UserDefaults.standard.set(bgOpacity, forKey: "W_CD_BgOpacity") } }
    
    // 草稿内容
    @Published var draftContent: String { didSet { UserDefaults.standard.set(draftContent, forKey: "W_CD_Content") } }
    @Published var showCursor: Bool { didSet { UserDefaults.standard.set(showCursor, forKey: "W_CD_ShowCursor") } }
    @Published var textColorHex: String { didSet { UserDefaults.standard.set(textColorHex, forKey: "W_CD_TextColor") } }
    @Published var cardBgHex: String { didSet { UserDefaults.standard.set(cardBgHex, forKey: "W_CD_CardBg") } }
    
    // 头像持久化数据
    @Published var avatarData: Data? {
        didSet {
            LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_CD_Av"), with: avatarData) {
                UserDefaults.standard.set($0, forKey: "W_CD_Av")
            }
        }
    }
    
    // 默认原图四行文本
    static let defaultDraftText = """
    *黑色钟表转动
    Tick-Tack @Doris
    :-使长廊回退'' plot twisted
    无法经由〈0000〉
    """
    
    init() {
        let ud = UserDefaults.standard
        self.isAddedToDesktop = ud.bool(forKey: "W_CD_Added")
        self.widgetPage = ud.integer(forKey: "W_CD_Page")
        self.widgetRow = ud.object(forKey: "W_CD_Row") != nil ? ud.integer(forKey: "W_CD_Row") : 2
        self.widgetCol = ud.integer(forKey: "W_CD_Col") > 0 ? 2 : 0
        
        self.bgColorMode = ud.string(forKey: "W_CD_BgMode") ?? "color"
        self.bgColorHex = ud.string(forKey: "W_CD_BgColor") ?? "#F4F5F7"
        self.bgOpacity = ud.object(forKey: "W_CD_BgOpacity") != nil ? ud.double(forKey: "W_CD_BgOpacity") : 1.0
        
        // 安全获取文字，防空白机制
        let savedText = ud.string(forKey: "W_CD_Content") ?? ""
        self.draftContent = savedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? Self.defaultDraftText : savedText
        
        self.showCursor = ud.object(forKey: "W_CD_ShowCursor") != nil ? ud.bool(forKey: "W_CD_ShowCursor") : true
        self.textColorHex = ud.string(forKey: "W_CD_TextColor") ?? "#3A3A3C"
        self.cardBgHex = ud.string(forKey: "W_CD_CardBg") ?? "#FFFFFF"
        
        if let id = ud.string(forKey: "W_CD_Av") {
            self.avatarData = LocalImageStore.shared.load(id: id)
        }
    }
    
    // 保证文字绝不为空
    func ensureValidContent() -> String {
        if draftContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            draftContent = Self.defaultDraftText
        }
        return draftContent
    }
}

// 消除 Swift 6 跨 actor 协议并发告警
extension ChatDraftWidgetManager: @preconcurrency DesktopWidgetManager {}

// MARK: - 3. 独立光标叶子组件（物理隔离动画事务，绝不污染父视图与头像）
private struct DraftBlinkingCursor: View {
    let color: Color
    let s: CGFloat
    @State private var isVisible: Bool = true
    
    var body: some View {
        Rectangle()
            .fill(color)
            .frame(width: 1.4 * s, height: 11 * s)
            .opacity(isVisible ? 1.0 : 0.15)
            .onAppear {
                withAnimation(.easeInOut(duration: 0.65).repeatForever(autoreverses: true)) {
                    isVisible.toggle()
                }
            }
    }
}

// MARK: - 4. 2×2 精密交互小组件视图
struct ChatDraftWidget2x2View: View {
    @ObservedObject var manager = ChatDraftWidgetManager.shared
    var showDashedBorder: Bool = false
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    // 桌面编辑与内存缓冲状态
    @State private var localDraftText: String = ""
    @State private var isEditing: Bool = false
    @FocusState private var isFieldFocused: Bool
    
    // 动效弹性状态
    @State private var atButtonScale: CGFloat = 1.0
    
    // 触觉发生器
    private let lightImpact = UIImpactFeedbackGenerator(style: .light)
    private let notifyImpact = UINotificationFeedbackGenerator()
    
    private var actualBackground: Color {
        if manager.bgColorMode == "transparent" {
            return Color.clear
        } else {
            return Color(hex: manager.bgColorHex).opacity(manager.bgOpacity)
        }
    }
    
    // 安全有效的正文文本
    private var effectiveText: String {
        if isEditing {
            return localDraftText.isEmpty ? manager.ensureValidContent() : localDraftText
        }
        return manager.ensureValidContent()
    }
    
    // 拆分单行渲染
    private var displayLines: [String] {
        let content = effectiveText
        let raw = content.components(separatedBy: "\n")
        let trimmed = raw.map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        return trimmed.isEmpty ? [content] : trimmed
    }
    
    var body: some View {
        let s = uiScale
        
        ZStack(alignment: .topLeading) {
            // 背景层
            actualBackground
                .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
            
            VStack(alignment: .leading, spacing: 8 * s) {
                // 顶部左侧：标准人像头像
                standardAvatarView(s: s)
                    .padding(.top, 14 * s)
                    .padding(.leading, 14 * s)
                
                // 下方：白色拟态聊天输入卡片
                VStack(alignment: .leading, spacing: 0) {
                    
                    // 中间文字区域
                    ZStack(alignment: .topLeading) {
                        if isEditing {
                            TextField("输入文本...".tr, text: $localDraftText, axis: .vertical)
                                .font(.system(size: 9.2 * s, weight: appearance.systemFontWeight))
                                .foregroundColor(Color(hex: manager.textColorHex))
                                .lineLimit(1...5)
                                .focused($isFieldFocused)
                                .onSubmit {
                                    commitSendAnimation()
                                }
                                .padding(.horizontal, 9 * s)
                                .padding(.top, 8 * s)
                                .padding(.bottom, 7 * s)
                        } else {
                            VStack(alignment: .leading, spacing: 3.2 * s) {
                                ForEach(Array(displayLines.enumerated()), id: \.offset) { index, line in
                                    HStack(spacing: 2 * s) {
                                        if index == 0 && manager.showCursor {
                                            DraftBlinkingCursor(color: Color(hex: manager.textColorHex), s: s)
                                        }
                                        
                                        // 智能蓝色艾特文本
                                        Text(renderMentionAttributedString(line, s: s))
                                            .lineLimit(1)
                                            .minimumScaleFactor(0.5)
                                    }
                                }
                            }
                            .padding(.horizontal, 9 * s)
                            .padding(.top, 8 * s)
                            .padding(.bottom, 7 * s)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                startEditingAnimation()
                            }
                        }
                    }
                    
                    // 水平细分割线
                    Rectangle()
                        .fill(Color.black.opacity(0.06))
                        .frame(height: 0.6 * s)
                        .padding(.horizontal, 9 * s)
                    
                    // 底部操作栏
                    HStack(alignment: .center, spacing: 9.5 * s) {
                        Image(systemName: "face.smiling")
                            .font(.system(size: 11.5 * s, weight: .regular))
                            .foregroundColor(Color(hex: "#1C1C1E"))
                        
                        Button(action: {
                            triggerAtAnimation()
                        }) {
                            Image(systemName: "at")
                                .font(.system(size: 11.5 * s, weight: isEditing ? .bold : .semibold))
                                .foregroundColor(isEditing ? Color(hex: "#007AFF") : Color(hex: "#1C1C1E"))
                                .scaleEffect(atButtonScale)
                        }
                        .buttonStyle(.plain)
                        
                        Image(systemName: "photo")
                            .font(.system(size: 10.5 * s, weight: .regular))
                            .foregroundColor(Color(hex: "#1C1C1E"))
                        
                        Spacer()
                        
                        Button(action: {
                            if isEditing {
                                commitSendAnimation()
                            } else {
                                startEditingAnimation()
                            }
                        }) {
                            Circle()
                                .fill(isEditing ? Color(hex: "#007AFF") : Color(hex: "#C7C7CC"))
                                .frame(width: 19 * s, height: 19 * s)
                                .overlay(
                                    Image(systemName: "arrow.up")
                                        .font(.system(size: 9.5 * s, weight: .bold))
                                        .foregroundColor(.white)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 9 * s)
                    .padding(.vertical, 6.5 * s)
                }
                .background(Color(hex: manager.cardBgHex))
                .clipShape(RoundedRectangle(cornerRadius: 13 * s, style: .continuous))
                .animation(.spring(response: 0.35, dampingFraction: 0.75), value: isEditing)
                .animation(.spring(response: 0.35, dampingFraction: 0.75), value: displayLines.count)
                .padding(.horizontal, 11 * s)
                .padding(.bottom, 11 * s)
            }
            
            // 桌面编辑边界虚线
            RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                .stroke(
                    manager.bgColorMode == "transparent" ? (showDashedBorder ? Color.secondary.opacity(0.4) : .clear) : Color.primary.opacity(0.06),
                    style: StrokeStyle(lineWidth: 1 * s, dash: (manager.bgColorMode == "transparent" && showDashedBorder) ? [5 * s, 4 * s] : [])
                )
                .allowsHitTesting(false)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        .onAppear {
            localDraftText = manager.ensureValidContent()
            lightImpact.prepare()
        }
        // 修复废弃 API 警告：采用 iOS 17+ 标准规范的闭包形式
        .onChange(of: manager.draftContent) { _, newText in
            if !isEditing {
                localDraftText = newText
            }
        }
    }
    
    // MARK: - 展开与收缩动效
    private func startEditingAnimation() {
        lightImpact.impactOccurred()
        localDraftText = manager.ensureValidContent()
        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
            isEditing = true
            isFieldFocused = true
        }
    }
    
    private func triggerAtAnimation() {
        lightImpact.impactOccurred()
        if !isEditing {
            localDraftText = manager.ensureValidContent()
        }
        
        withAnimation(.spring(response: 0.2, dampingFraction: 0.5)) {
            atButtonScale = 1.25
        }
        withAnimation(.spring(response: 0.2, dampingFraction: 0.7).delay(0.1)) {
            atButtonScale = 1.0
        }
        
        if localDraftText.isEmpty || localDraftText.hasSuffix(" ") || localDraftText.hasSuffix("\n") {
            localDraftText += "@"
        } else {
            localDraftText += " @"
        }
        
        if !isEditing {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                isEditing = true
                isFieldFocused = true
            }
        }
    }
    
    private func commitSendAnimation() {
        notifyImpact.notificationOccurred(.success)
        let cleaned = localDraftText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !cleaned.isEmpty {
            manager.draftContent = localDraftText
        } else {
            localDraftText = manager.ensureValidContent()
        }
        
        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
            isFieldFocused = false
            isEditing = false
        }
    }
    
    // MARK: - 轻量富文本解析
    private func renderMentionAttributedString(_ line: String, s: CGFloat) -> AttributedString {
        let translated = translator.translate(line)
        var attributed = AttributedString(translated)
        attributed.foregroundColor = Color(hex: manager.textColorHex)
        attributed.font = .system(size: 9.2 * s, weight: appearance.systemFontWeight)
        
        let words = translated.components(separatedBy: " ")
        for word in words where word.hasPrefix("@") && word.count > 1 {
            if let range = attributed.range(of: word) {
                attributed[range].foregroundColor = Color(hex: "#007AFF")
                attributed[range].font = .system(size: 9.2 * s, weight: .semibold)
            }
        }
        return attributed
    }
    
    // 标准人像头像
    private func standardAvatarView(s: CGFloat) -> some View {
        let size: CGFloat = 36 * s
        return Group {
            if let data = manager.avatarData, let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
            } else {
                ZStack {
                    Color(hex: "#E5E5EA")
                    Image(systemName: "person.fill")
                        .font(.system(size: 17 * s))
                        .foregroundColor(Color(hex: "#8E8E93"))
                        .offset(y: 1.0 * s)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(Circle().stroke(Color.primary.opacity(0.06), lineWidth: 0.8 * s))
        .transaction { $0.animation = nil }
    }
}

// MARK: - 5. 注册中心连接
extension WidgetRegistry {
    func registerChatDraftWidget() {
        let mgr = ChatDraftWidgetManager.shared
        let s = uiScale
        registerWidget(
            id: "chat_draft",
            title: "草稿卡片".tr,
            subtitle: "拟态对话草稿可编辑便签".tr,
            badge: "2×2",
            manager: mgr,
            desktopView: { ChatDraftWidget2x2View(manager: mgr) },
            previewView: { ChatDraftWidget2x2View(manager: mgr).frame(width: 160 * s, height: 160 * s) },
            editSheetView: { show in EditChatDraftWidgetSheet(isPresented: show) }
        )
    }
}
