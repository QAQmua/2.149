// 📄 完整替换文件：Widgets/WidgetFanFolder.swift
import SwiftUI
import PhotosUI
import CoreText

// MARK: - 1. 自动装配插座
final class FanFolderWidgetPlugin: BaseWidgetPlugin {
    @MainActor override class func register() {
        WidgetRegistry.shared.registerFanFolderWidget()
    }
}

// MARK: - 2. 状态管理器 (支持 iPad 动态文件导入与自动持久化)
@MainActor
final class FanFolderWidgetManager: ObservableObject {
    static let shared = FanFolderWidgetManager()
    
    nonisolated var sizeRows: Int { 2 }
    nonisolated var sizeCols: Int { 2 }
    
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: "W_FF_Added") } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: "W_FF_Page") } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: "W_FF_Row") } }
    @Published var widgetCol: Int { didSet { UserDefaults.standard.set(widgetCol, forKey: "W_FF_Col") } }
    
    @Published var folderColorHex: String { didSet { UserDefaults.standard.set(folderColorHex, forKey: "W_FF_Color") } }
    
    // 动态字体名称与展示名称
    @Published var customFontPostScript: String = ""
    @Published var customFontDisplayName: String = "" {
        didSet { UserDefaults.standard.set(customFontDisplayName, forKey: "W_FF_FontDisplay") }
    }
    
    // 5 张照片数据
    @Published var photo1Data: Data? { didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_FF_P1"), with: photo1Data) { UserDefaults.standard.set($0, forKey: "W_FF_P1") } } }
    @Published var photo2Data: Data? { didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_FF_P2"), with: photo2Data) { UserDefaults.standard.set($0, forKey: "W_FF_P2") } } }
    @Published var photo3Data: Data? { didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_FF_P3"), with: photo3Data) { UserDefaults.standard.set($0, forKey: "W_FF_P3") } } }
    @Published var photo4Data: Data? { didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_FF_P4"), with: photo4Data) { UserDefaults.standard.set($0, forKey: "W_FF_P4") } } }
    @Published var photo5Data: Data? { didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_FF_P5"), with: photo5Data) { UserDefaults.standard.set($0, forKey: "W_FF_P5") } } }
    
    // 信件内容（完全自定）
    @Published var photo1Text: String { didSet { UserDefaults.standard.set(photo1Text, forKey: "W_FF_T1") } }
    @Published var photo2Text: String { didSet { UserDefaults.standard.set(photo2Text, forKey: "W_FF_T2") } }
    @Published var photo3Text: String { didSet { UserDefaults.standard.set(photo3Text, forKey: "W_FF_T3") } }
    @Published var photo4Text: String { didSet { UserDefaults.standard.set(photo4Text, forKey: "W_FF_T4") } }
    @Published var photo5Text: String { didSet { UserDefaults.standard.set(photo5Text, forKey: "W_FF_T5") } }
    
    @Published var photo1Sign: String { didSet { UserDefaults.standard.set(photo1Sign, forKey: "W_FF_S1") } }
    @Published var photo2Sign: String { didSet { UserDefaults.standard.set(photo2Sign, forKey: "W_FF_S2") } }
    @Published var photo3Sign: String { didSet { UserDefaults.standard.set(photo3Sign, forKey: "W_FF_S3") } }
    @Published var photo4Sign: String { didSet { UserDefaults.standard.set(photo4Sign, forKey: "W_FF_S4") } }
    @Published var photo5Sign: String { didSet { UserDefaults.standard.set(photo5Sign, forKey: "W_FF_S5") } }
    
    @Published var photo1Date: String { didSet { UserDefaults.standard.set(photo1Date, forKey: "W_FF_D1") } }
    @Published var photo2Date: String { didSet { UserDefaults.standard.set(photo2Date, forKey: "W_FF_D2") } }
    @Published var photo3Date: String { didSet { UserDefaults.standard.set(photo3Date, forKey: "W_FF_D3") } }
    @Published var photo4Date: String { didSet { UserDefaults.standard.set(photo4Date, forKey: "W_FF_D4") } }
    @Published var photo5Date: String { didSet { UserDefaults.standard.set(photo5Date, forKey: "W_FF_D5") } }
    
    init() {
        let ud = UserDefaults.standard
        self.isAddedToDesktop = ud.bool(forKey: "W_FF_Added")
        self.widgetPage = ud.integer(forKey: "W_FF_Page")
        self.widgetRow = ud.object(forKey: "W_FF_Row") != nil ? ud.integer(forKey: "W_FF_Row") : 2
        self.widgetCol = ud.integer(forKey: "W_FF_Col") > 0 ? 2 : 0
        
        let savedColor = ud.string(forKey: "W_FF_Color")
        if savedColor == nil || savedColor == "#EAAEC6" {
            self.folderColorHex = "#B4D4EE"
            ud.set("#B4D4EE", forKey: "W_FF_Color")
        } else {
            self.folderColorHex = savedColor!
        }
        
        self.customFontDisplayName = ud.string(forKey: "W_FF_FontDisplay") ?? ""
        
        if let id1 = ud.string(forKey: "W_FF_P1") { self.photo1Data = LocalImageStore.shared.load(id: id1) }
        if let id2 = ud.string(forKey: "W_FF_P2") { self.photo2Data = LocalImageStore.shared.load(id: id2) }
        if let id3 = ud.string(forKey: "W_FF_P3") { self.photo3Data = LocalImageStore.shared.load(id: id3) }
        if let id4 = ud.string(forKey: "W_FF_P4") { self.photo4Data = LocalImageStore.shared.load(id: id4) }
        if let id5 = ud.string(forKey: "W_FF_P5") { self.photo5Data = LocalImageStore.shared.load(id: id5) }
        
        self.photo1Text = ud.string(forKey: "W_FF_T1") ?? ""
        self.photo2Text = ud.string(forKey: "W_FF_T2") ?? ""
        self.photo3Text = ud.string(forKey: "W_FF_T3") ?? ""
        self.photo4Text = ud.string(forKey: "W_FF_T4") ?? ""
        self.photo5Text = ud.string(forKey: "W_FF_T5") ?? ""
        
        self.photo1Sign = ud.string(forKey: "W_FF_S1") ?? ""
        self.photo2Sign = ud.string(forKey: "W_FF_S2") ?? ""
        self.photo3Sign = ud.string(forKey: "W_FF_S3") ?? ""
        self.photo4Sign = ud.string(forKey: "W_FF_S4") ?? ""
        self.photo5Sign = ud.string(forKey: "W_FF_S5") ?? ""
        
        self.photo1Date = ud.string(forKey: "W_FF_D1") ?? ""
        self.photo2Date = ud.string(forKey: "W_FF_D2") ?? ""
        self.photo3Date = ud.string(forKey: "W_FF_D3") ?? ""
        self.photo4Date = ud.string(forKey: "W_FF_D4") ?? ""
        self.photo5Date = ud.string(forKey: "W_FF_D5") ?? ""
        
        restoreSavedFont()
    }
    
    // 现代 iOS 18+ 规范：使用 URL 注册字体，彻底消除弃用警告
    func loadAndRegisterCustomFont(from url: URL) -> Bool {
        guard url.startAccessingSecurityScopedResource() else { return false }
        defer { url.stopAccessingSecurityScopedResource() }
        
        var error: Unmanaged<CFError>?
        _ = CTFontManagerRegisterFontsForURL(url as CFURL, .process, &error)
        
        if let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor],
           let first = descriptors.first,
           let psName = CTFontDescriptorCopyAttribute(first, kCTFontNameAttribute) as? String {
            self.customFontPostScript = psName
            self.customFontDisplayName = url.deletingPathExtension().lastPathComponent
            
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let dest = docs.appendingPathComponent("custom_handwriting_font.ttf")
            if let data = try? Data(contentsOf: url) {
                try? data.write(to: dest)
            }
            return true
        }
        return false
    }
    
    private func restoreSavedFont() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fontFile = docs.appendingPathComponent("custom_handwriting_font.ttf")
        guard FileManager.default.fileExists(atPath: fontFile.path) else { return }
        
        var error: Unmanaged<CFError>?
        _ = CTFontManagerRegisterFontsForURL(fontFile as CFURL, .process, &error)
        if let descriptors = CTFontManagerCreateFontDescriptorsFromURL(fontFile as CFURL) as? [CTFontDescriptor],
           let first = descriptors.first,
           let psName = CTFontDescriptorCopyAttribute(first, kCTFontNameAttribute) as? String {
            self.customFontPostScript = psName
        }
    }
    
    func clearCustomFont() {
        self.customFontPostScript = ""
        self.customFontDisplayName = ""
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fontFile = docs.appendingPathComponent("custom_handwriting_font.ttf")
        try? FileManager.default.removeItem(at: fontFile)
    }
    
    func photoData(at index: Int) -> Data? {
        switch index {
        case 0: return photo1Data
        case 1: return photo2Data
        case 2: return photo3Data
        case 3: return photo4Data
        case 4: return photo5Data
        default: return nil
        }
    }
    
    func letterContent(at index: Int) -> (text: String, sign: String, date: String) {
        switch index {
        case 0: return (photo1Text, photo1Sign, photo1Date)
        case 1: return (photo2Text, photo2Sign, photo2Date)
        case 2: return (photo3Text, photo3Sign, photo3Date)
        case 3: return (photo4Text, photo4Sign, photo4Date)
        case 4: return (photo5Text, photo5Sign, photo5Date)
        default: return ("", "", "")
        }
    }
}

extension FanFolderWidgetManager: @preconcurrency DesktopWidgetManager {}

// MARK: - 3. 2×2 扇形文件夹小组件
struct FanFolderWidget2x2View: View {
    @ObservedObject var manager = FanFolderWidgetManager.shared
    var showDashedBorder: Bool = false
    
    @State private var isFanned: Bool = false
    @State private var isCenterElevated: Bool = false
    @State private var centerTransitionBlur: CGFloat = 0
    @State private var elevateToken: Int = 0
    @State private var focusedIndex: Int? = nil
    @State private var isCardFlipped: Bool = false
    
    private let fanConfigs: [(angle: Double, x: CGFloat, y: CGFloat)] = [
        (-22.0, -46.0, -48.0),
        (-11.0, -23.0, -58.0),
        (  0.0,   0.0, -62.0),
        ( 11.0,  23.0, -58.0),
        ( 22.0,  46.0, -48.0)
    ]
    
    private let defaultPalettes: [Color] = [
        Color(hex: "#B8ADA1"),
        Color(hex: "#D6D1C9"),
        Color(hex: "#BA4924"),
        Color(hex: "#87827D"),
        Color(hex: "#CCC6BD")
    ]
    
    private var smoothSpring: Animation {
        .spring(response: 0.46, dampingFraction: 0.78, blendDuration: 0.08)
    }
    
    private var flipSpring: Animation {
        .spring(response: 0.52, dampingFraction: 0.76)
    }
    
    var body: some View {
        let s = uiScale
        let baseBottomPad: CGFloat = 8 * s
        
        ZStack(alignment: .bottom) {
            Color.clear
            
            folderBackplate(s: s)
                .padding(.bottom, baseBottomPad)
                .opacity(focusedIndex == nil ? 1.0 : 0.36)
                .animation(smoothSpring, value: focusedIndex)
                .onTapGesture {
                    handleFolderTap()
                }
            
            ZStack(alignment: .bottom) {
                ForEach(0..<5, id: \.self) { idx in
                    let isFocused = (focusedIndex == idx)
                    let isOtherFocused = (focusedIndex != nil && !isFocused)
                    let fanCfg = fanConfigs[idx]
                    
                    let currentCardW: CGFloat = isFocused ? (92 * s) : (isFanned ? (52 * s) : (54 * s))
                    let currentCardH: CGFloat = isFocused ? (102 * s) : (isFanned ? (58 * s) : (60 * s))
                    let collapsedX: CGFloat = CGFloat(idx - 2) * 13.0 * s
                    let showCardShadow = isFanned || isFocused
                    
                    let staggerDelay: Double = isFanned ? (Double(abs(idx - 2)) * 0.016) : (Double(2 - abs(idx - 2)) * 0.012)
                    let cardAnimation = smoothSpring.delay(staggerDelay)
                    let cardBlur: CGFloat = isOtherFocused ? 3 : (idx == 2 ? centerTransitionBlur : 0)
                    
                    flippablePhotoCard(
                        index: idx,
                        width: currentCardW,
                        height: currentCardH,
                        s: s,
                        isFocused: isFocused,
                        hasShadow: showCardShadow
                    )
                    .rotationEffect(
                        .degrees(isFocused ? 0 : (isFanned ? fanCfg.angle : 0)),
                        anchor: UnitPoint(x: 0.5, y: 1.0)
                    )
                    .offset(
                        x: isFocused ? 0 : (isFanned ? (fanCfg.x * s) : collapsedX),
                        y: isFocused ? (-10 * s) : (isFanned ? (fanCfg.y * s) : 0)
                    )
                    .scaleEffect(isOtherFocused ? 0.88 : 1.0)
                    .opacity(isOtherFocused ? 0.0 : 1.0)
                    .blur(radius: cardBlur)
                    .zIndex(
                        isFocused ? 999 : (
                            isCenterElevated ? (idx == 2 ? 10 : Double(idx < 2 ? idx : (4 - idx)))
                            : Double(4 - idx)
                        )
                    )
                    .animation(cardAnimation, value: isFanned)
                    .animation(smoothSpring, value: focusedIndex)
                    .onTapGesture {
                        handleCardTap(index: idx)
                    }
                }
            }
            .padding(.bottom, baseBottomPad + (3 * s))
            
            folderFrontPocket(s: s)
                .padding(.bottom, baseBottomPad)
                .opacity(focusedIndex == nil ? 1.0 : 0.36)
                .animation(smoothSpring, value: focusedIndex)
                .contentShape(Rectangle())
                .onTapGesture {
                    handleFolderTap()
                }
            
            if showDashedBorder {
                RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                    .stroke(Color.secondary.opacity(0.3), style: StrokeStyle(lineWidth: 0.8 * s, dash: [4 * s, 4 * s]))
                    .allowsHitTesting(false)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    // MARK: - 3D 翻转卡片
    private func flippablePhotoCard(
        index: Int,
        width: CGFloat,
        height: CGFloat,
        s: CGFloat,
        isFocused: Bool,
        hasShadow: Bool
    ) -> some View {
        let isThisCardFlipped = isFocused && isCardFlipped
        
        return ZStack {
            cardFrontSide(index: index, width: width, height: height, s: s)
                .opacity(isThisCardFlipped ? 0 : 1)
            
            if isFocused {
                cardBackSide(index: index, width: width, height: height, s: s)
                    .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                    .opacity(isThisCardFlipped ? 1 : 0)
            }
        }
        .frame(width: width, height: height)
        .clipShape(RoundedRectangle(cornerRadius: 10 * s, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 10 * s, style: .continuous)
                .stroke(Color.white.opacity(0.85), lineWidth: 0.8 * s)
        )
        .rotation3DEffect(
            .degrees(isThisCardFlipped ? 180 : 0),
            axis: (x: 0, y: 1, z: 0),
            perspective: 0.35
        )
        .animation(flipSpring, value: isCardFlipped)
        .shadow(color: Color.black.opacity(hasShadow ? 0.12 : 0.0), radius: 5 * s, y: 2.5 * s)
    }
    
    private func cardFrontSide(index: Int, width: CGFloat, height: CGFloat, s: CGFloat) -> some View {
        let photoData = manager.photoData(at: index)
        return ZStack {
            if let data = photoData, let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
                    .frame(width: width, height: height)
                    .clipped()
            } else {
                defaultPalettes[index % defaultPalettes.count]
                    .frame(width: width, height: height)
            }
        }
    }
    
    private func cardBackSide(index: Int, width: CGFloat, height: CGFloat, s: CGFloat) -> some View {
        let content = manager.letterContent(at: index)
        
        return ZStack {
            Color.white
            
            VStack(alignment: .leading, spacing: 0) {
                ScrollView(showsIndicators: false) {
                    renderLetterText(
                        text: content.text.isEmpty ? "点击编辑背面写信...".tr : content.text,
                        isEmpty: content.text.isEmpty,
                        size: 11 * s,
                        s: s
                    )
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 10 * s)
                    .padding(.horizontal, 10 * s)
                }
                
                Spacer(minLength: 4 * s)
                
                VStack(alignment: .trailing, spacing: 2 * s) {
                    if !content.sign.isEmpty {
                        renderLetterText(text: content.sign, isEmpty: false, size: 9.5 * s, s: s)
                    }
                    if !content.date.isEmpty {
                        renderLetterText(text: content.date, isEmpty: false, size: 8.5 * s, s: s, isDate: true)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.horizontal, 10 * s)
                .padding(.bottom, 9 * s)
            }
        }
        .frame(width: width, height: height)
    }
    
    @ViewBuilder
    private func renderLetterText(text: String, isEmpty: Bool, size: CGFloat, s: CGFloat, isDate: Bool = false) -> some View {
        let baseColor = isEmpty ? Color.gray.opacity(0.35) : (isDate ? Color.gray.opacity(0.75) : Color(hex: "#222222"))
        
        if !manager.customFontPostScript.isEmpty {
            Text(text)
                .font(.custom(manager.customFontPostScript, size: size))
                .lineSpacing(4 * s)
                .foregroundColor(baseColor)
        } else {
            Text(text)
                .font(.system(size: size, weight: .light, design: .serif))
                .italic()
                .tracking(0.5 * s)
                .lineSpacing(4 * s)
                .foregroundColor(baseColor)
        }
    }
    
    private func triggerCenterBlurPulse() {
        centerTransitionBlur = 4.5
        withAnimation(.easeOut(duration: 0.32)) {
            centerTransitionBlur = 0
        }
    }
    
    private func updateElevation(to target: Bool, delayMs: UInt64) {
        elevateToken += 1
        let currentToken = elevateToken
        if delayMs == 0 {
            isCenterElevated = target
            return
        }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: delayMs * 1_000_000)
            if elevateToken == currentToken {
                isCenterElevated = target
            }
        }
    }
    
    private func handleCardTap(index: Int) {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        if focusedIndex == index {
            withAnimation(flipSpring) {
                isCardFlipped.toggle()
            }
        } else if isFanned {
            isCardFlipped = false
            withAnimation(smoothSpring) {
                focusedIndex = index
            }
        } else {
            isCardFlipped = false
            withAnimation(smoothSpring) {
                isFanned = true
                triggerCenterBlurPulse()
                updateElevation(to: true, delayMs: 140)
            }
        }
    }
    
    private func handleFolderTap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        if focusedIndex != nil {
            withAnimation(smoothSpring) {
                focusedIndex = nil
                isCardFlipped = false
                updateElevation(to: isFanned, delayMs: 0)
            }
        } else {
            let nextFanned = !isFanned
            withAnimation(smoothSpring) {
                isFanned = nextFanned
                triggerCenterBlurPulse()
                if nextFanned {
                    updateElevation(to: true, delayMs: 140)
                } else {
                    updateElevation(to: false, delayMs: 220)
                }
            }
        }
    }
    
    private func folderBackplate(s: CGFloat) -> some View {
        CleanFolderBackShape()
            .fill(Color(hex: manager.folderColorHex))
            .frame(width: 116 * s, height: 80 * s)
            .shadow(color: Color.black.opacity(0.04), radius: 5 * s, y: 2.5 * s)
    }
    
    private func folderFrontPocket(s: CGFloat) -> some View {
        CleanFolderFrontShape()
            .fill(Color.white.opacity(0.68))
            .background(
                CleanFolderFrontShape()
                    .fill(.ultraThinMaterial.opacity(0.55))
            )
            .frame(width: 116 * s, height: 50 * s)
            .overlay(
                CleanFolderFrontShape()
                    .stroke(
                        LinearGradient(
                            colors: [Color.white.opacity(0.95), Color.white.opacity(0.30)],
                            startPoint: .top,
                            endPoint: .bottom
                        ),
                        lineWidth: 0.8 * s
                    )
            )
            .shadow(color: Color.black.opacity(0.04), radius: 5 * s, y: 2.5 * s)
    }
}

private struct CleanFolderBackShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let w = rect.width
        let h = rect.height
        let r: CGFloat = 12
        let tabW: CGFloat = w * 0.45
        let tabH: CGFloat = 12
        let tabR: CGFloat = 8
        
        path.move(to: CGPoint(x: 0, y: tabR))
        path.addQuadCurve(to: CGPoint(x: tabR, y: 0), control: CGPoint(x: 0, y: 0))
        path.addLine(to: CGPoint(x: tabW - tabR, y: 0))
        path.addQuadCurve(to: CGPoint(x: tabW, y: tabR), control: CGPoint(x: tabW, y: 0))
        
        path.addCurve(
            to: CGPoint(x: tabW + 9, y: tabH),
            control1: CGPoint(x: tabW, y: tabH - 2),
            control2: CGPoint(x: tabW + 4, y: tabH)
        )
        
        path.addLine(to: CGPoint(x: w - r, y: tabH))
        path.addQuadCurve(to: CGPoint(x: w, y: tabH + r), control: CGPoint(x: w, y: tabH))
        path.addLine(to: CGPoint(x: w, y: h - r))
        path.addQuadCurve(to: CGPoint(x: w - r, y: h), control: CGPoint(x: w, y: h))
        path.addLine(to: CGPoint(x: r, y: h))
        path.addQuadCurve(to: CGPoint(x: 0, y: h - r), control: CGPoint(x: 0, y: h))
        path.addLine(to: CGPoint(x: 0, y: tabR))
        path.closeSubpath()
        return path
    }
}

private struct CleanFolderFrontShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let w = rect.width
        let h = rect.height
        let r: CGFloat = 14
        let topR: CGFloat = 6
        
        path.move(to: CGPoint(x: 0, y: topR))
        path.addQuadCurve(to: CGPoint(x: topR, y: 0), control: CGPoint(x: 0, y: 0))
        path.addLine(to: CGPoint(x: w - topR, y: 0))
        path.addQuadCurve(to: CGPoint(x: w, y: topR), control: CGPoint(x: w, y: 0))
        path.addLine(to: CGPoint(x: w, y: h - r))
        path.addQuadCurve(to: CGPoint(x: w - r, y: h), control: CGPoint(x: w, y: h))
        path.addLine(to: CGPoint(x: r, y: h))
        path.addQuadCurve(to: CGPoint(x: 0, y: h - r), control: CGPoint(x: 0, y: h))
        path.closeSubpath()
        return path
    }
}

// MARK: - 4. 注册中心连接
extension WidgetRegistry {
    func registerFanFolderWidget() {
        let mgr = FanFolderWidgetManager.shared
        let s = uiScale
        registerWidget(
            id: "fan_folder",
            title: "相片文件夹",
            subtitle: "淡蓝文件夹 · 扇形展开与大图预览",
            badge: "2×2",
            manager: mgr,
            desktopView: { FanFolderWidget2x2View(manager: mgr) },
            previewView: { FanFolderWidget2x2View(manager: mgr).frame(width: 160 * s, height: 160 * s) },
            editSheetView: { show in EditFanFolderWidgetSheet(isPresented: show) }
        )
    }
}
