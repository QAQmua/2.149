import SwiftUI

final class PhoneAppPlugin: BaseAppPlugin {
    override class var id: String { "phone" }
    override class var name: String { "电话" }
    override class var icon: String { "phone.fill" }
    override class var colorName: String { "green" }
    override class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(PhoneView(show: show))
    }
}

struct PhoneView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("拨号键盘 (待开发)".tr)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(.gray)
            }
            .navigationTitle(lang.tr("app_phone"))
            .navigationBarTitleDisplayMode(.inline)
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}
